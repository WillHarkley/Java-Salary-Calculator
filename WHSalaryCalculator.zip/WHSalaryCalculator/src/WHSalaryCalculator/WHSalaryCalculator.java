//Assignment 2 Purpose to build a salary calculator that intakes the employee name, pay rate, and hours worked. Returning the total earnings based on the information given.

package WHSalaryCalculator;

import java.util.Scanner;


public class WHSalaryCalculator {

	public static void main(String[] args) {
		
		System.out.println("William Harkley Assignment 2");

		Scanner input = new Scanner(System.in);
		
		//initialization phase
		double pay;
		double rate = 0;
		double hours = 0;
		String employee;
		
		
		//processing phase
		System.out.print("Employee name: "); //stores employee name from prompt
		employee = input.next();
		
		System.out.print("Enter rate of pay: "); //stores rate of pay from prompt
		rate = input.nextDouble();
			
		System.out.print("Enter hours worked: "); //stores hours worked from user prompt
		hours = input.nextDouble();
		
		//termination phase
		
		if (hours < 40)
		{
			pay = rate * hours; //earnings calculation
		}
		else
		{
			pay = (40 * rate) + ((1.5 * rate)*(hours - 40));
		}
		
		System.out.printf("%s", employee); //identifies user
		System.out.printf("%n Earned %.2f", pay); //provides earnings total
		
		
	}

}
